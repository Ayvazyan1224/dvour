<?php
/*
Plugin Name: Woo Mixed Products
Plugin URI: https://facebook.com/alarayv/
Description: Plugin for selling few products together
Version: 1.0
Author: A.A.V.
Author URI: https://facebook.com/alarayv/
*/
if(isset($_GET['sub']) && isset($_GET['date'])) {
    add_action('init', 'do_session_start');
    function do_session_start()
    {
        if (!session_id()) session_start();
    }
    add_action('woocommerce_after_shop_loop', 'add_or_remove_html');
    function add_or_remove_html()
    {
        wp_enqueue_script('shop_script', plugins_url() . '/mixpro/shop.js');

    }
    /*add_action('wp_footer', 'session_destroy_prods', 1000);
    function session_destroy_prods() {
        if($_GET['action']=='menu') {
            session_destroy();
            session_unset();
        }
    }*/

    //require_once(plugins_url()."/mixpro/mycart.php");
    add_action('wp_head', 'add_or_remove_product');

    function add_or_remove_product()
    {
        ?>
        <script>
            ajaxurl = "<?php echo get_site_url();?>/wp-admin/admin-ajax.php";
            jQuery(document).ready(function () {
                jQuery('.plus').click(function () {
                    var data = {
                        'action': 'add_or_remove',
                        'prod': jQuery(this).parent().parent().find('a').attr('title')
                    };
                    jQuery.post(ajaxurl, data, function (response) {
                        /*JSON TO ARRAY*/
                        /*JSON TO ARRAY*/
                        var arr = JSON.parse(response);
                        jQuery('.mymeels').prepend("<li class='product'><a href=''>" + arr.thumb + "</a> </li>");
                        console.log(arr);

                    });
                });
            });
        </script>
        <?php

    }
    add_action('wp_footer', 'add_next_button', 1000);
    function add_next_button (){
    $nextbutton = "<a href='".get_stylesheet_directory_uri()."/cart/?sub=".$_GET['sub']."&date=".$_GET['date']."&action=add_to_cart' class='next_add_to_cart'>NEXT</a>";
    ?>
        <script>jQuery(document).ready(
            function(){
                jQuery('.archive ul.products').append("<?php echo $nextbutton;?>");
            });
        </script>
        <style>
            .next_add_to_cart {
                display: block;
                background: #f15a38;
                width: 300px;
                text-align: center;
                float: right;
                z-index: 99999;
                clear: both;
                color: #fff;
                padding: 10px;
                font-family: DINProMedium;
            }
        </style>
        <?php
}

}




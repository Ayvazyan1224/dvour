<?php
//require_once ("http://".$_SERVER['HTTP_HOST']."/cit/wp-load.php");

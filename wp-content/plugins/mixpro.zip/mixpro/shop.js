i=0;
jQuery('.item-info').prepend('<div class="addremove"><button class="minus">-</button><span>'+i+'</span><button class="plus">+</button></div>');
jQuery('.plus').click(function(){if(parseInt(jQuery(this).parent().find('span').html())>=0)
{jQuery(this).parent().find('span').html(parseInt(jQuery(this).parent().find('span').html())+1)}
jQuery.ajax
});
jQuery('.minus').click(function(){if(parseInt(jQuery(this).parent().find('span').html())>0){jQuery(this).parent().find('span').html(parseInt(jQuery(this).parent().find('span').html())-1)}});


jQuery('.archive.post-type-archive.post-type-archive-product li.product-type-subscription,li.product-type-variable-subscription ').remove();